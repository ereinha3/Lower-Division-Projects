# Mallard test programs

In this directory are a few simple programs that can be used
for testing the compiler. 

